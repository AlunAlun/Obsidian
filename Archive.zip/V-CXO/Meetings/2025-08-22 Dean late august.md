---
date: 2025-08-22 15:42
type: meeting
company: "[[Assuring Business]]"
summary: " "
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-08-22-Friday]]

**Attendees**: 
- [[Dean Smith]]

## Notes
- Look into fractional CXO groups
- Look into reddit groups

## Action Points
- Long article:
	- Alun to write article on Rohan's impact at Freeverse
		- describe images you want or find them on deposit photos
	- Dean to write BPO/Shared Services at Zurich

