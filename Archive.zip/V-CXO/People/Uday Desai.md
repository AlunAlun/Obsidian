---
location: Bangalore
company: "[[V-Align]]"
title: CEO
email: uday@v-align.in
aliases:
---
tags:: [[👥 People MOC]]
## Notes
- IT industry 3 decades, from bangalore
- Implemented banking software, programmer initially
- Second compamy,; first company had 300 people, customers in NY. Sold company and got interested in business processe
- Started V-Align 15 as interested in CRM. Was found on linked and got first break with Zoho in Oman.
- Number 1 partner of 800 zoho partners. Rated as 27th out of 15K partners bu Zoho
- 87 people - want to reach 200
- Built AI and RPA models in org, want to be independent, want Zoho to be one pillar, AI and RPA as pillars. Now they are merging - hyper automation
- Cater to 20 nations from Zoho, other product lines in India only
- Have much interest from investors - but valuation not good if only zoho
- 75% from Zoho, 25% fro AI and RPA. Want to flip to 50/50, and then to 40/60.
- 15-20 people well aligned with US market.
- 70% margin on subscription of products, only 18-30 on zoho/salesforce
- AI is MVP only
- 

## Meetings
```dataview
TABLE file.cday as Created, summary AS "Summary"
FROM "V-CXO/Meetings" where contains(file.outlinks, [[]])
SORT file.cday DESC
```