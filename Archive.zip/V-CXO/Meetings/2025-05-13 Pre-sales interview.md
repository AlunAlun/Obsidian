---
date: 2025-05-13 09:26
type: Online
company: "[[V-Align]]"
summary: First call with Uday and Dean
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-05-13-Tuesday]]
**Attendees**: 
- [[Dean Smith]]
- [[Uday Desai]]

## Agenda/Questions
- Describe V-Align for me
- Defer to Dean to negotiations
- Funding experience
- Global leadership remote working
- Cultural exposure - US is a very different market (I've been to US 5-6 times a year, we have contacts)
- There will be some budget needed to spend -might need some investment first
- Localization of resources. UAE - EMEA GCC as a region. Europe really benefits as a separate office cls reputation of Dubai as an office.

## Notes
- See summary in initial notes on [[Uday Desai]]
