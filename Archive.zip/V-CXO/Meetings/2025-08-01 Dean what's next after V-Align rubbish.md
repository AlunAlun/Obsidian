---
date: 2025-08-01 16:10
type: meeting
company: 
summary: " "
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-08-01-Friday]]

**Attendees**: 
- 

## Notes
- Concise, friendly, professional. Not long-winded
- Key messages get repeated

## Action Points
- Alun write product descriptions
- Check if Google discriminates SEO based on British/American spelling
- Dean to make draft MOU
- Alun email Tania and Johan to tell them something's happening and MOU happening

