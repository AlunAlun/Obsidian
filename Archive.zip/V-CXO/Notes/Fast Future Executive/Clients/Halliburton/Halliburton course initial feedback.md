General structure (slide): I think the modules are well structured and make sense. One thing that I think would help is to have a single thread that ties the whole thing together. One thought I had was to have a single 'example use-case' which we can build on as we progress through the modules. E.g. we follow the journey of a company in certain sector (aviation, healthcare, whatever) as it gradually transforms and adapts to the modern digital era? People like an analogy to ground what their learning into a real use case.


Slide 15: The flow wasn't clear to me upon first reading - only when I saw the numbers did it begin to make sense. I wonder if reversing the slide to go top-down would help? Maybe make the numbering bigger? Also maybe draw horizontal lines/bands from the categories on the LHS? 

General comments on the modules: The images on the right of the 'second slide' for each module, are difficult to understand without reading the left hand side text in detail (the text in them is very small). Maybe number them and cross-reference them in the text?

Module 5: I like that there are lots of buzzwords here, but this module in particular would benefit from the 'common use case' I mentioned earlier

My CV: Please see below an updated CV - both for use in this deck, and in wider usage (e.g. on the FFE site)

**Dr. Alun Evans, Barcelona**

- Virtual CXO, AssuringBusiness.com
- Former CEO & Co-Founder, Freeverse.io
- Former CEO, Shar3d.com
- Former CTO, Bodypal.com
- Ph.D. Medical Physics
- Co-Author, _The Fast Future Blur_
- Instructor, Caltech Future Skills Academy
    
Dr. Alun Evans has over 20 years of experience in technology leadership, product strategy, fundraising, and corporate management. As CEO, CTO, and Virtual CXO, he has successfully led multidisciplinary teams across multiple sectors, with deep expertise in building scalable digital businesses and delivering results-driven collaborative environments. He has raised significant venture funding, driven product development across both startup and enterprise contexts, and advised companies on strategic growth.

An experienced communicator and educator, Alun has delivered executive training for international corporations and spoken at over 50 global conferences. With a Ph.D. in Physics and a strong technical foundation, he combines engineering, software development, and business leadership to bridge the gap between technology and strategic execution. His technical knowledge spans multiple programming languages, digital workflows, and emerging technologies.


