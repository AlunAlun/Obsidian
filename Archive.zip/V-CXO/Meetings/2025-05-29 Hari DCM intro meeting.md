---
date: 2025-05-29 17:08
type: Online
company: "[[Fast Future Executive]]"
summary: Hari introducing basic plan for DCM
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-05-29-Thursday]]

**Attendees**: 
- [[Hari Aburri]]
## Notes
- Head of Leadership development said to Hari: there is a Graduate leadershing training program (GET), every big companies hires from these. They are looking for their GETs to develop the next level of critical thinking skills. We need to know "what would be the profile" 
- *How do we develop the next phase of engineering leadership for the company that can help develop ideas for growth?*. In the context of new tech like AI, new business models etc.
- GETs are usually very very clever, but rubbish at communication
- Family run business, very traditional - once you're in, you're in, trust based sales process
- Presentation to CHRO
- Calibrate how we present, who presents which slides
- Need to take from ideas to actionable plans
- Interviewing key people/stakeholder interviews - 8-10 to get a sense of the business
- Hari and I were design methodology starting from what he has
- Likely to be max of 20 people. Better 15-20. If in groups, 4 groups max.
- Can be done as individuals or groups, up to them.
- Of fees, 20% will go to FFE. 80% shared between Hari and Alun. FFE pays air-travel
- Slides:
	- Hari start
	- Alun does lab itself: sections 3-4
	- Hari does 5
	- Both do 6
	- Hari leads commercials

## Action Points
- Familiarise with Sections 3 and 4
- Set up call Dean + Hari
- 

