[[🗣️ Meetings MOC]] 

[[👥 People MOC]] 

[[📈 Companies MOC]]

[📧 Mail](https://outlook.office.com/mail/)

[💾 V-Align Drive](https://wizzics-my.sharepoint.com/personal/dean_assuringbusiness_com/_layouts/15/onedrive.aspx?id=%2Fpersonal%2Fdean_assuringbusiness_com%2FDocuments%2FVCXO%2FClients%2FV-Align&ga=1)

## To-do


- [ ] Move sublime vault to iCloud
- [ ] School Xmas products
- [ ] Make Blockchain article into whitepaper
- [ ] Find another boiler person
- [ ] GPT for auto deck analysis
	- [ ] landing page for deck analysis

- [x] Chase Ziggy Booking ✅ 2025-11-19
- [ ] Megamenu - Dean

- [x] Email Uday thanks and proposal ✅ 2025-11-19

- [ ] Chase Toni new LAOS article and check socials



- [ ] Chase John⏳ 2025-11-18 




- [ ] Add paragraph on Services page to describe different categories
- [ ] Look at duplicated images on VCXO website







