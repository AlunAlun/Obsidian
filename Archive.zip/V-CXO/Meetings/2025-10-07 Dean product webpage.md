---
date: 2025-10-07 11:37
type: meeting
company: "[[Assuring Business]]"
summary: " "
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-10-07-Tuesday]]

**Attendees**: 
- [[Dean Smith]]

## Notes
- Virtual team - maybe more of a temporary based thing
- Managed service - outcome based, 'higher' than virtual team
- Canva
- Deposit photos

## Action Points
- 

