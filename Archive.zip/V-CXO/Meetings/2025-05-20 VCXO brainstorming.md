---
date: 2025-05-20 14:31
type: meeting
company: "[[Assuring Business]]"
summary: Dean and I discussing initial ideas for V-CXO formal spin-off
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-05-20-Tuesday]]

**Attendees**: 
- [[Dean Smith]]

## Notes
- Alun to lead
- Link to strategic plan slide on slides, phase 1, 2, and 3
- Build up business to around 1M in cash, either sell for multiple or withdraw
- Partnerships: hiring firms, tech PS cos like accenture
- Flavour what we offer based on who's on the books
- Commissions scheme for people we bring in
- Targeted pages for ICPs and geographies
- Maybe tiers of membership (lower margin if you're contributing to VCXOs)
- Managed services - acquire a marketing agency and use it as a fractional resource
- Initial task: JTBD
- Dean wants to keep 66% - come with a proposal to dean so I get >10%
- Maybe look into opening an S.L. as a vehicle to not pay wealth tax
- Next step: MOU within a couple of weeks

## JTBD
- prepare proposal to Dean for my %
