---
date: 2025-06-13 17:41
type: Online
company: "[[Fast Future Executive]]"
summary: Intro meeting between Hari and Dean
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-06-13-Friday]]

**Attendees**: 
- [[Hari Aburri]]
- [[Dean Smith]]

## Notes
- General intros and obvious collaboration opportunities
- Hari noted something interesting at the end regarding VCXO space. Larger companies are concerned about confidentiality and IP protection when hiring fractional roles, so we should mention how important we take this, very early on in the sales process 

## Action Points
- Dean to send MNDA to Hari
- Follow up in a couple of weeks

