---
date: 2025-11-04 10:13
type: meeting
company: "[[Slow Lettuce]]"
summary: First call with Jeremy regarding possible CXO
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-11-04-Tuesday]]

**Attendees**: 
- [[Jeremy Lefebre]]
- Alun Evans

## Agenda/Questions
- Find out about Slow Lettuce
- See if Virtual CXOs can help

## Notes
- Slow Lettuce is a group of freelancers incorporating soon
- Wants to hire CPO to Jeremy can focus on growing the business
- Interested in fractional approach as company is not incorporated and could be good fit

## Action Points
- Send Virtual CXO deck to Jeremy
- Send Alun CV tailored to design
- Send 1-page pitch

