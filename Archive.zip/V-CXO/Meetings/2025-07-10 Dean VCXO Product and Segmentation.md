---
date: 2025-07-10 14:49
type: meeting
company: "[[Assuring Business]]"
summary: Dean and I discussing product structure
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-07-10-Thursday]]

**Attendees**: 
- [[Dean Smith]]

## Notes


Top-layer: VCXO
- Virtual - more remote: global
- Fractional - hybrid/part-time: proxmity
- INTERIM - obvious

Mid-layer Consulting
 - Strategic Catalyst - general
 - Operational Catalyst - focused
 - Capital Catalyst - VC/M&A
 - (Team Catalyst? - use disc model to find where your management team is lacking skills)
 - Gain-share-> "Success based/projects" or "Outcome Based Solutions" or something - minimum cost-cover +10% + risk investment based on outcome
 - Consulting - deliverable-based projects
 Training separate

Bottom layer
- Virtual Team
- Managed Services
- Performance optimisation

Target markets/geography
- EU + Middle East as main target
- Poke US and Asia

Segmentation verticals:
 - Tech
 - Telco
 - Finance and Financial Services (Johan)

Segmentation Horizontals
- M&A
- Finance
- BPO
- IT
- Marketing

Messaging
- Need position for general
- Need positioning for the matrix
- 

For meeting make clear
- Tania and Johan and Me and Dean will be the initial resources: we will be earning money while building it

Eventually we'll need two whatsapp groups - one for us four (leadership) and one with others


## Action Points
- Alun to take lead on organizing the meeting - and also lead the meeting session itself
- Buy Traction by Geno Wickman

