https://www.asociacionaev.org/admin159753/uploads/uploads_doc/estandares/134449_Estandar_Sostenibilidad_Aprobacion_JD_20250723.pdf

https://www.boe.es/buscar/doc.php?id=BOE-A-2025-11815

## Fire
Official link
https://www.miteco.gob.es/es/biodiversidad/servicios/banco-datos-naturaleza/informacion-disponible/incendios-forestales.html

Forest data
https://www.miteco.gob.es/es/cartografia-y-sig/ide/descargas/biodiversidad/mfe.html?utm_source=chatgpt.com


Dataset
https://zenodo.org/records/15798999
Software
https://github.com/JulenErcibengoaTekniker/IberFire

## Water
Viewer
https://sig.miteco.gob.es/snczi/
Data sources
https://www.miteco.gob.es/es/cartografia-y-sig/ide/descargas/agua/riesgo-inundacion-fluvial-t10.html
