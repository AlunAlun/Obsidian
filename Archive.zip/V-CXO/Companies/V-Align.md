---
location: Bangalore
website: https://v-align.in
aliases:
---
tags:: [[📈 Companies MOC]]
## Notes
- See [[Uday Desai]] for company history notes

## People
```dataview
TABLE file.cday as Created, summary AS "Summary"
FROM "V-CXO/People" where contains(file.outlinks, [[]])
SORT file.cday DESC
```

## Meetings
```dataview
TABLE file.cday as Created, summary AS "Summary"
FROM "V-CXO/Meetings" where contains(file.outlinks, [[]])
SORT file.cday DESC
```