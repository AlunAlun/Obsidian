---
date: 2025-05-20 13:58
type: Online
company: "[[V-Align]]"
summary: " "
---
tags: [[🗣️ Meetings MOC]]
Date: [[2025-05-20-Tuesday]]

**Attendees**: 
- Mahentesh
- Ajid
- [[Uday Desai]]

## Notes
- Basically a meeting to get to know each 
- Ajit was worried about AI boom and getting money tied up
- Need strategy and plan
- Need reaction plan to changes

## AI Summary


## Transcript

